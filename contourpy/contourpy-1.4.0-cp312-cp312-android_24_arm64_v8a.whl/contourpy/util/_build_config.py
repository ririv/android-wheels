# _build_config.py.in is converted into _build_config.py during the meson build process.

from __future__ import annotations


def build_config() -> dict[str, str]:
    """
    Return a dictionary containing build configuration settings.

    All dictionary keys and values are strings, for example ``False`` is
    returned as ``"False"``.

        .. versionadded:: 1.1.0
    """
    return dict(
        # Python settings
        python_version="3.12",
        python_install_dir=r"/usr/local/lib/python3.12/site-packages/",
        python_path=r"/home/runner/work/py-extra-wheels/py-extra-wheels/chaquopy/server/pypi/android-wheel-recipe-j_t_w4nb/build/1.4.0/cp312-cp312-android_24_arm64_v8a/env/bin/python",

        # Package versions
        contourpy_version="1.4.0",
        meson_version="1.12.1",
        mesonpy_version="0.22.1",
        pybind11_version="3.1.0",

        # Misc meson settings
        meson_backend="ninja",
        build_dir=r"/home/runner/work/py-extra-wheels/py-extra-wheels/chaquopy/server/pypi/android-wheel-recipe-j_t_w4nb/build/1.4.0/cp312-cp312-android_24_arm64_v8a/src/.mesonpy-7oubaykz/lib/contourpy/util",
        source_dir=r"/home/runner/work/py-extra-wheels/py-extra-wheels/chaquopy/server/pypi/android-wheel-recipe-j_t_w4nb/build/1.4.0/cp312-cp312-android_24_arm64_v8a/src/lib/contourpy/util",
        cross_build="True",

        # Build options
        build_options=r"-Dbuildtype=release -Db_ndebug=if-release -Db_vscrt=md -Dvsenv=true --cross-file=/home/runner/work/py-extra-wheels/py-extra-wheels/scripts/build/meson/arm64-v8a.ini --native-file=/home/runner/work/py-extra-wheels/py-extra-wheels/chaquopy/server/pypi/android-wheel-recipe-j_t_w4nb/build/1.4.0/cp312-cp312-android_24_arm64_v8a/src/.mesonpy-7oubaykz/meson-python-native-file.ini",
        buildtype="release",
        cpp_std="c++17",
        debug="False",
        optimization="3",
        vsenv="True",
        b_ndebug="if-release",
        b_vscrt="from_buildtype",

        # C++ compiler
        compiler_name="clang",
        compiler_version="18.0.4",
        linker_id="ld.lld",
        compile_command="/home/runner/work/py-extra-wheels/py-extra-wheels/chaquopy/server/pypi/android-wheel-recipe-j_t_w4nb/build/1.4.0/cp312-cp312-android_24_arm64_v8a/wrappers/aarch64-linux-android24-clang++",

        # Host machine
        host_cpu="aarch64",
        host_cpu_family="aarch64",
        host_cpu_endian="little",
        host_cpu_system="android",

        # Build machine, same as host machine if not a cross_build
        build_cpu="x86_64",
        build_cpu_family="x86_64",
        build_cpu_endian="little",
        build_cpu_system="linux",
    )
