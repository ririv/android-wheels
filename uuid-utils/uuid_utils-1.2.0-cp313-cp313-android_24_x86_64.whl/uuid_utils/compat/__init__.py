from uuid import (
    NAMESPACE_DNS,
    NAMESPACE_OID,
    NAMESPACE_URL,
    NAMESPACE_X500,
    RESERVED_FUTURE,
    RESERVED_MICROSOFT,
    RESERVED_NCS,
    RFC_4122,
    UUID,
    SafeUUID,
    getnode,
)

import uuid_utils
from uuid_utils import _uuid4_int, _uuid7_int

NIL = UUID("00000000-0000-0000-0000-000000000000")
MAX = UUID("ffffffff-ffff-ffff-ffff-ffffffffffff")

__version__ = uuid_utils.__version__


def _from_int(n: int) -> UUID:
    u = object.__new__(UUID)
    object.__setattr__(u, "int", n)
    object.__setattr__(u, "is_safe", SafeUUID.unknown)
    return u


def uuid1(node=None, clock_seq=None):
    """Generate a UUID from a host ID, sequence number, and the current time.
    If 'node' is not given, getnode() is used to obtain the hardware
    address.  If 'clock_seq' is given, it is used as the sequence number;
    otherwise a random 14-bit sequence number is chosen."""
    return _from_int(uuid_utils.uuid1(node, clock_seq).int)


def uuid3(namespace, name):
    """Generate a UUID from the MD5 hash of a namespace UUID and a name."""
    namespace = uuid_utils.UUID(namespace.hex) if namespace else namespace
    return _from_int(uuid_utils.uuid3(namespace, name).int)


def uuid4():
    """Generate a random UUID."""
    return _from_int(_uuid4_int())


def uuid5(namespace, name):
    """Generate a UUID from the SHA-1 hash of a namespace UUID and a name."""
    namespace = uuid_utils.UUID(namespace.hex) if namespace else namespace
    return _from_int(uuid_utils.uuid5(namespace, name).int)


def uuid6(node=None, clock_seq=None):
    """Similar to `uuid1` but where fields are ordered differently
    for improved DB locality.

    More precisely, given a 60-bit timestamp value as specified for UUIDv1,
    for UUIDv6 the first 48 most significant bits are stored first, followed
    by the 4-bit version (same position), followed by the remaining 12 bits
    of the original 60-bit timestamp.
    """
    return _from_int(uuid_utils.uuid6(node, clock_seq).int)


def uuid7(*, nanoseconds=None):
    """Generate a UUID from a Unix timestamp in milliseconds and random bits.

    UUIDv7 objects feature monotonicity within a millisecond.
    """
    return _from_int(_uuid7_int(nanoseconds=nanoseconds))


def uuid8(a=None, b=None, c=None):
    """Generate a UUID from three custom blocks.

    * 'a' is the first 48-bit chunk of the UUID (octets 0-5);
    * 'b' is the mid 12-bit chunk (octets 6-7);
    * 'c' is the last 62-bit chunk (octets 8-15).

    When a value is not specified, a pseudo-random value is generated.
    """
    return _from_int(uuid_utils.uuid8(a, b, c).int)


__all__ = [
    "MAX",
    "NAMESPACE_DNS",
    "NAMESPACE_OID",
    "NAMESPACE_URL",
    "NAMESPACE_X500",
    "NIL",
    "RESERVED_FUTURE",
    "RESERVED_MICROSOFT",
    "RESERVED_NCS",
    "RFC_4122",
    "UUID",
    "__version__",
    "getnode",
    "uuid1",
    "uuid3",
    "uuid4",
    "uuid5",
    "uuid6",
    "uuid7",
    "uuid8",
]
