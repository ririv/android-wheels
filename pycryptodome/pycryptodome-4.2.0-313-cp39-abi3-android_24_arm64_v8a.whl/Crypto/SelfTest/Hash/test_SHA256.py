#
#  SelfTest/Hash/test_SHA256.py: Self-test for the SHA-256 hash function
#
# Written in 2008 by Dwayne C. Litzenberger <dlitz@dlitz.net>
#
# ===================================================================
# The contents of this file are dedicated to the public domain.  To
# the extent that dedication to the public domain is not available,
# everyone is granted a worldwide, perpetual, royalty-free,
# non-exclusive license to exercise all rights associated with the
# contents of this file for any purpose whatsoever.
# No rights are reserved.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
# BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
# ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
# ===================================================================

"""Self-test suite for Crypto.Hash.SHA256"""

import hashlib

import pytest

from Crypto.Hash import SHA256
from Crypto.Protocol.KDF import PBKDF2
from Crypto.SelfTest.Hash.common import make_hash_tests, sha_ni_required
from Crypto.Util import _cpu_features

# The implementation selected at import time (the fixture below replaces it)
_default_lib = SHA256._raw_sha256_lib

# Run every test with each C implementation available on this machine
_implementations = [pytest.param(SHA256._raw_sha256_portable_lib, id="portable")]
if SHA256._raw_sha256_shani_lib is not None:
    _implementations.append(pytest.param(SHA256._raw_sha256_shani_lib, id="shani"))


@pytest.fixture(autouse=True, params=_implementations)
def sha256_implementation(request, monkeypatch):
    monkeypatch.setattr(SHA256, "_raw_sha256_lib", request.param)


class TestImplementations:
    # Required in CI on x86_64 (AMD64) runners known to support SHA-NI,
    # so that a fallback to the portable implementation is not silent
    @pytest.mark.skipif(not sha_ni_required(), reason="SHA-NI not required (see sha_ni_required)")
    def test_sha_ni_available(self):
        assert _cpu_features.have_sha_ni(), "SHA-NI not detected on this CPU"
        assert SHA256._raw_sha256_shani_lib is not None, "SHA-NI module not built"
        assert _default_lib is SHA256._raw_sha256_shani_lib, "SHA-NI module not selected"

    def test_all_lengths(self):
        # Every padding case, over one and two blocks
        data = bytes(range(256)) * 2
        for length in range(300):
            assert SHA256.new(data[:length]).digest() == hashlib.sha256(data[:length]).digest()

    def test_oneshot_all_lengths(self):
        data = bytes(range(256)) * 2
        for length in range(300):
            assert SHA256.digest(data[:length]) == hashlib.sha256(data[:length]).digest()

    def test_chunks(self):
        # Partial and whole blocks, in any order
        data = bytes(range(256)) * 8
        for chunk_sizes in ((1, 63, 64, 65, 200), (64, 64, 1, 127, 300), (3, 500, 7, 129)):
            h = SHA256.new()
            pos = 0
            for size in chunk_sizes:
                h.update(data[pos : pos + size])
                pos += size
            assert h.digest() == hashlib.sha256(data[:pos]).digest()

    def test_pbkdf2(self):
        expected = hashlib.pbkdf2_hmac("sha256", b"password", b"salt", 1000, 2 * 32 + 1)
        assert PBKDF2(b"password", b"salt", 2 * 32 + 1, 1000, hmac_hash_module=SHA256) == expected


@pytest.mark.slow
class TestLargeSHA256:
    def test(self):
        """SHA256: 512/520 MiB test"""
        zeros = bytes([0x00]) * (1024 * 1024)

        h = SHA256.new(zeros)
        for _i in range(511):
            h.update(zeros)

        # This test vector is from PyCrypto's old testdata.py file.
        assert h.hexdigest() == "9acca8e8c22201155389f65abbf6bc9723edc7384ead80503839f49dcc56d767"  # 512 MiB

        for _i in range(8):
            h.update(zeros)

        # This test vector is from PyCrypto's old testdata.py file.
        assert h.hexdigest() == "abf51ad954b246009dfe5a50ecd582fd5b8f1b8b27f30393853c3ef721e7fa6e"  # 520 MiB


# Test vectors from FIPS PUB 180-2
# This is a list of (expected_result, input[, description]) tuples.
test_data = [
    # FIPS PUB 180-2, B.1 - "One-Block Message"
    ("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad", "abc"),
    # FIPS PUB 180-2, B.2 - "Multi-Block Message"
    (
        "248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1",
        "abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq",
    ),
    # FIPS PUB 180-2, B.3 - "Long Message"
    ("cdc76e5c9914fb9281a1c7e284d73e67f1809a48a497200e046d39ccc7112cd0", "a" * 10**6, '"a" * 10**6'),
    # Test for an old PyCrypto bug.
    (
        "f7fd017a3c721ce7ff03f3552c0813adcc48b7f33f07e5e2ba71e23ea393d103",
        "This message is precisely 55 bytes long, to test a bug.",
        "Length = 55 (mod 64)",
    ),
    # Example from http://de.wikipedia.org/wiki/Secure_Hash_Algorithm
    ("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855", ""),
    (
        "d32b568cd1b96d459e7291ebf4b25d007f275c9f13149beeb782fac0716613f8",
        "Franz jagt im komplett verwahrlosten Taxi quer durch Bayern",
    ),
]


TestVectors = make_hash_tests(SHA256, "SHA256", test_data, digest_size=32, oid="2.16.840.1.101.3.4.2.1")
